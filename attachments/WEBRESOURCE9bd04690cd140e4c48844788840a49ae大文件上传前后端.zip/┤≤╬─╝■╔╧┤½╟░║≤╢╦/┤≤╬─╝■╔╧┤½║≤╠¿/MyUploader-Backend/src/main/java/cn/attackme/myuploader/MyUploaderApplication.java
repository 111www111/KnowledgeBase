package cn.attackme.myuploader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyUploaderApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyUploaderApplication.class, args);
    }
}
